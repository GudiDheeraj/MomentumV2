// ============================================================================
// Momentum Tracker extension — default config
// ============================================================================
// AUTO-GENERATED from the root .env file — do not edit by hand, your
// changes will be overwritten. Edit ../.env instead, then re-run
// `python generate_frontend_env.py`.
//
// This is only the DEFAULT the extension ships with. Whatever's set on the
// extension's own Settings page (chrome.storage) always takes precedence,
// so you can still point one installed copy at a different backend without
// re-editing this file.

self.MOMENTUM_DEFAULT_API_BASE = "http://localhost:8000";
